package metodos;

/**
 * Created by alan on 28/09/16.
 */
public class Metodos {

    /**
     * Print's & Println's
     */

    public static void print(String mensaje){
        System.out.print(mensaje);
    }

    public static void print(int mensaje){
        System.out.print(mensaje);
    }

    public static void println(String mensaje){
        System.out.println(mensaje);
    }

    public static void println(int mensaje){
        System.out.println(mensaje);
    }
}
